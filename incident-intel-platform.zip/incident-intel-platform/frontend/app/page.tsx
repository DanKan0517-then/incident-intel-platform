"use client";
import { useEffect, useState } from "react";
import useSWR from "swr";
import PredictionForm from "./components/PredictionForm";
import IncidentTable from "./components/IncidentTable";
import RiskBadge from "./components/RiskBadge";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE;
const fetcher = (url: string) => fetch(url).then((r) => r.json());

export default function Home() {
  const { data: incidents, mutate } = useSWR(`${API_BASE}/incidents`, fetcher, { refreshInterval: 15000 });
  const [lastResult, setLastResult] = useState<any>(null);

  useEffect(() => {
    if (lastResult) mutate();
  }, [lastResult, mutate]);

  return (
    <main style={{ maxWidth: 960, margin: "0 auto", padding: 32 }}>
      <h1>AI Incident Intelligence</h1>
      <p style={{ opacity: 0.7 }}>Real-time risk scoring for production services, backed by an XGBoost model tracked in MLflow.</p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginTop: 24 }}>
        <PredictionForm onResult={setLastResult} />
        <div style={{ background: "#131722", padding: 20, borderRadius: 12 }}>
          <h3 style={{ marginTop: 0 }}>Latest prediction</h3>
          {lastResult ? (
            <div style={{ display: "grid", gap: 8 }}>
              <div style={{ fontSize: 32, fontWeight: 700 }}>{(lastResult.risk_score * 100).toFixed(1)}%</div>
              <RiskBadge severity={lastResult.severity} />
              <div style={{ opacity: 0.6, fontSize: 12 }}>model: {lastResult.model_version}</div>
            </div>
          ) : (
            <p style={{ opacity: 0.6 }}>Run a prediction to see results here.</p>
          )}
        </div>
      </div>

      <section style={{ marginTop: 32 }}>
        <h3>Recent incidents</h3>
        <IncidentTable incidents={incidents} />
      </section>
    </main>
  );
}
