"use client";
import { useState } from "react";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE;

export default function PredictionForm({ onResult }: { onResult: (r: any) => void }) {
  const [form, setForm] = useState({
    service_name: "checkout-api",
    error_rate: 0.05,
    latency_p99_ms: 300,
    cpu_utilization: 0.5,
    memory_utilization: 0.5,
    deploy_frequency_24h: 1,
  });
  const [loading, setLoading] = useState(false);

  const update = (key: string, value: string) =>
    setForm((f) => ({ ...f, [key]: key === "service_name" ? value : parseFloat(value) }));

  const submit = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      onResult(await res.json());
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ background: "#131722", padding: 20, borderRadius: 12, display: "grid", gap: 10 }}>
      <h3 style={{ margin: 0 }}>Score a service</h3>
      <input placeholder="Service name" value={form.service_name} onChange={(e) => update("service_name", e.target.value)} />
      <label>Error rate: {form.error_rate}
        <input type="range" min={0} max={1} step={0.01} value={form.error_rate} onChange={(e) => update("error_rate", e.target.value)} />
      </label>
      <label>Latency p99 (ms): {form.latency_p99_ms}
        <input type="range" min={0} max={2000} step={10} value={form.latency_p99_ms} onChange={(e) => update("latency_p99_ms", e.target.value)} />
      </label>
      <label>CPU utilization: {form.cpu_utilization}
        <input type="range" min={0} max={1} step={0.01} value={form.cpu_utilization} onChange={(e) => update("cpu_utilization", e.target.value)} />
      </label>
      <label>Memory utilization: {form.memory_utilization}
        <input type="range" min={0} max={1} step={0.01} value={form.memory_utilization} onChange={(e) => update("memory_utilization", e.target.value)} />
      </label>
      <label>Deploys / 24h: {form.deploy_frequency_24h}
        <input type="range" min={0} max={10} step={1} value={form.deploy_frequency_24h} onChange={(e) => update("deploy_frequency_24h", e.target.value)} />
      </label>
      <button onClick={submit} disabled={loading} style={{ padding: "8px 16px", borderRadius: 8, background: "#3b82f6", color: "white", border: "none", cursor: "pointer" }}>
        {loading ? "Scoring..." : "Predict risk"}
      </button>
    </div>
  );
}
