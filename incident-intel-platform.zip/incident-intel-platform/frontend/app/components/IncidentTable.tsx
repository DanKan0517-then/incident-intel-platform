import RiskBadge from "./RiskBadge";

export default function IncidentTable({ incidents }: { incidents: any[] }) {
  if (!incidents?.length) {
    return <p style={{ opacity: 0.6 }}>No incidents recorded yet.</p>;
  }
  return (
    <table style={{ width: "100%", borderCollapse: "collapse" }}>
      <thead>
        <tr style={{ textAlign: "left", opacity: 0.7, fontSize: 13 }}>
          <th style={{ padding: 8 }}>Service</th>
          <th style={{ padding: 8 }}>Risk</th>
          <th style={{ padding: 8 }}>Severity</th>
          <th style={{ padding: 8 }}>Status</th>
          <th style={{ padding: 8 }}>Created</th>
        </tr>
      </thead>
      <tbody>
        {incidents.map((i) => (
          <tr key={i.id} style={{ borderTop: "1px solid #232838" }}>
            <td style={{ padding: 8 }}>{i.service_name}</td>
            <td style={{ padding: 8 }}>{i.risk_score?.toFixed(2)}</td>
            <td style={{ padding: 8 }}><RiskBadge severity={i.severity || "low"} /></td>
            <td style={{ padding: 8 }}>{i.status}</td>
            <td style={{ padding: 8 }}>{new Date(i.created_at).toLocaleString()}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
