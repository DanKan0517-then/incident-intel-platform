export const metadata = {
  title: "Incident Intelligence",
  description: "Real-time production incident risk dashboard",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "system-ui, sans-serif", margin: 0, background: "#0b0e14", color: "#e6e8ee" }}>
        {children}
      </body>
    </html>
  );
}
