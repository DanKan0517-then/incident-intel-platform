variable "aws_region"    { default = "us-east-1" }
variable "project"       { default = "incident-intel" }
variable "environment"   { default = "production" }
variable "db_username"   { default = "incident" }
variable "db_password"   { sensitive = true }
variable "node_instance_type" { default = "t3.medium" }
