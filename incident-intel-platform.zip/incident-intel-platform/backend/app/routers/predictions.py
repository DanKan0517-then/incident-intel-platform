from fastapi import APIRouter

from app.cache import cache_get, cache_set
from app.ml.predictor import predict
from app.schemas import IncidentFeatures, PredictionResponse
from app.streaming.producer import publish_incident_event

router = APIRouter(prefix="/predict", tags=["predictions"])


@router.post("", response_model=PredictionResponse)
def predict_incident(features: IncidentFeatures):
    payload = features.model_dump()
    cache_key = f"pred:{hash(frozenset(payload.items()))}"

    cached = cache_get(cache_key)
    if cached:
        return PredictionResponse(**cached)

    result = predict(payload)
    cache_set(cache_key, result)
    publish_incident_event({**payload, **result})

    return PredictionResponse(**result)
