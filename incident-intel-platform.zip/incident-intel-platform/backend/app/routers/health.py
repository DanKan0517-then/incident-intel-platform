from fastapi import APIRouter

from app.config import get_settings
from app.ml.predictor import get_model
from app.schemas import HealthOut

router = APIRouter(tags=["health"])
settings = get_settings()


@router.get("/health", response_model=HealthOut)
def health():
    model, _ = get_model()
    return HealthOut(status="ok", env=settings.ENV, model_loaded=model is not None)


@router.get("/")
def root():
    return {"service": settings.APP_NAME, "docs": "/docs"}
