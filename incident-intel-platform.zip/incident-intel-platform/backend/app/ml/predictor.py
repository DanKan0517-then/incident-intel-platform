import threading
from typing import Optional

import mlflow

from app.config import get_settings
from app.ml.features import to_feature_vector, severity_from_score

settings = get_settings()
_lock = threading.Lock()
_model = None
_model_version: Optional[str] = None


def _load_model():
    """
    Loads the latest model for MODEL_STAGE from the MLflow Model Registry.
    Falls back to None if nothing has been trained/registered yet, so the
    API can still boot (and report model_loaded=False on /health).
    """
    global _model, _model_version
    mlflow.set_tracking_uri(settings.MLFLOW_TRACKING_URI)
    client = mlflow.tracking.MlflowClient()
    name = "incident-risk-xgboost"
    try:
        versions = client.search_model_versions(f"name='{name}'")
        if not versions:
            return
        latest = sorted(versions, key=lambda v: int(v.version))[-1]
        uri = f"models:/{name}/{latest.version}"
        _model = mlflow.pyfunc.load_model(uri)
        _model_version = latest.version
    except Exception:
        _model = None
        _model_version = None


def get_model():
    with _lock:
        if _model is None:
            _load_model()
        return _model, _model_version


def predict(payload: dict) -> dict:
    model, version = get_model()
    features = to_feature_vector(payload)

    if model is None:
        # Deterministic heuristic fallback so the API stays useful
        # before the first model has been trained/registered.
        score = min(
            1.0,
            0.5 * payload["error_rate"] * 5
            + 0.2 * payload["cpu_utilization"]
            + 0.2 * payload["memory_utilization"]
            + 0.1 * min(payload["deploy_frequency_24h"] / 10, 1),
        )
        return {"risk_score": round(score, 4), "severity": severity_from_score(score), "model_version": "heuristic-fallback"}

    proba = model.predict(features)
    score = float(proba[0] if hasattr(proba, "__len__") else proba)
    return {"risk_score": round(score, 4), "severity": severity_from_score(score), "model_version": str(version)}


def reload_model():
    global _model, _model_version
    with _lock:
        _model = None
        _model_version = None
        _load_model()
