"""
Trains an XGBoost classifier that predicts the probability a service is
heading toward a production incident, and logs the run + model to MLflow.

Run locally:
    python -m app.ml.train
"""
import numpy as np
import mlflow
import mlflow.xgboost
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score

from app.config import get_settings
from app.ml.features import FEATURE_ORDER

settings = get_settings()


def _make_synthetic_dataset(n: int = 4000, seed: int = 42):
    """
    Synthetic incident telemetry. Replace with a real feature store /
    warehouse query once historical incident data is available.
    """
    rng = np.random.default_rng(seed)
    error_rate = rng.beta(2, 20, n)
    latency = rng.gamma(2.0, 80, n)
    cpu = rng.beta(2, 3, n)
    mem = rng.beta(2, 3, n)
    deploys = rng.poisson(1.5, n)

    risk = (
        3.0 * error_rate
        + 0.004 * latency
        + 1.2 * cpu
        + 1.0 * mem
        + 0.15 * deploys
        + rng.normal(0, 0.3, n)
    )
    threshold = np.quantile(risk, 0.8)
    label = (risk >= threshold).astype(int)

    X = np.column_stack([error_rate, latency, cpu, mem, deploys])
    return X, label


def train_and_log() -> str:
    mlflow.set_tracking_uri(settings.MLFLOW_TRACKING_URI)
    mlflow.set_experiment(settings.MLFLOW_EXPERIMENT_NAME)

    X, y = _make_synthetic_dataset()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    params = {
        "n_estimators": 250,
        "max_depth": 4,
        "learning_rate": 0.05,
        "subsample": 0.9,
        "colsample_bytree": 0.9,
        "eval_metric": "logloss",
        "random_state": 42,
    }

    with mlflow.start_run(run_name="xgboost-incident-risk") as run:
        model = xgb.XGBClassifier(**params)
        model.fit(X_train, y_train)

        preds = model.predict(X_test)
        proba = model.predict_proba(X_test)[:, 1]

        metrics = {
            "auc": roc_auc_score(y_test, proba),
            "accuracy": accuracy_score(y_test, preds),
            "f1": f1_score(y_test, preds),
        }

        mlflow.log_params(params)
        mlflow.log_params({"features": ",".join(FEATURE_ORDER)})
        mlflow.log_metrics(metrics)
        mlflow.xgboost.log_model(
            model,
            artifact_path="model",
            registered_model_name="incident-risk-xgboost",
        )

        print(f"Run {run.info.run_id} logged. Metrics: {metrics}")
        return run.info.run_id


if __name__ == "__main__":
    train_and_log()
