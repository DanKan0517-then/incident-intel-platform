import numpy as np

FEATURE_ORDER = [
    "error_rate",
    "latency_p99_ms",
    "cpu_utilization",
    "memory_utilization",
    "deploy_frequency_24h",
]


def to_feature_vector(payload: dict) -> np.ndarray:
    return np.array([[payload[f] for f in FEATURE_ORDER]], dtype=float)


def severity_from_score(score: float) -> str:
    if score >= 0.75:
        return "critical"
    if score >= 0.5:
        return "high"
    if score >= 0.25:
        return "medium"
    return "low"
