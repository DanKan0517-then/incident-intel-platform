import json
from typing import Optional

import redis

from app.config import get_settings

settings = get_settings()
_client: Optional[redis.Redis] = None


def get_client() -> Optional[redis.Redis]:
    global _client
    if _client is None:
        try:
            _client = redis.from_url(settings.REDIS_URL, socket_connect_timeout=1)
            _client.ping()
        except Exception:
            _client = None
    return _client


def cache_get(key: str):
    client = get_client()
    if client is None:
        return None
    val = client.get(key)
    return json.loads(val) if val else None


def cache_set(key: str, value, ttl: int = None):
    client = get_client()
    if client is None:
        return
    client.set(key, json.dumps(value), ex=ttl or settings.CACHE_TTL_SECONDS)
