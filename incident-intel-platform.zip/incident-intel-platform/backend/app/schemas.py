import uuid
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class IncidentFeatures(BaseModel):
    service_name: str = Field(..., examples=["checkout-api"])
    error_rate: float = Field(..., ge=0, le=1, description="Fraction of failed requests")
    latency_p99_ms: float = Field(..., ge=0)
    cpu_utilization: float = Field(..., ge=0, le=1)
    memory_utilization: float = Field(..., ge=0, le=1)
    deploy_frequency_24h: float = Field(..., ge=0, description="Deploys in the last 24h")


class PredictionResponse(BaseModel):
    risk_score: float
    severity: str
    model_version: Optional[str] = None


class IncidentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    service_name: str
    error_rate: float
    latency_p99_ms: float
    cpu_utilization: float
    memory_utilization: float
    deploy_frequency_24h: float
    risk_score: Optional[float]
    severity: Optional[str]
    status: str
    created_at: datetime


class HealthOut(BaseModel):
    status: str
    env: str
    model_loaded: bool
