import os
from functools import lru_cache


class Settings:
    APP_NAME: str = "AI Incident Intelligence Platform"
    ENV: str = os.getenv("ENV", "development")

    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", "postgresql+psycopg2://incident:incident@localhost:5432/incidents"
    )
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    KAFKA_BOOTSTRAP_SERVERS: str = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
    KAFKA_INCIDENT_TOPIC: str = os.getenv("KAFKA_INCIDENT_TOPIC", "incident-events")

    MLFLOW_TRACKING_URI: str = os.getenv("MLFLOW_TRACKING_URI", "sqlite:///./mlflow.db")
    MLFLOW_EXPERIMENT_NAME: str = os.getenv("MLFLOW_EXPERIMENT_NAME", "incident-risk-prediction")
    MODEL_STAGE: str = os.getenv("MODEL_STAGE", "Production")

    CACHE_TTL_SECONDS: int = int(os.getenv("CACHE_TTL_SECONDS", "60"))


@lru_cache
def get_settings() -> Settings:
    return Settings()
