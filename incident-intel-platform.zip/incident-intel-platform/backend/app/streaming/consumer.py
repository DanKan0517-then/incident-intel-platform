"""
Standalone worker: consumes incident telemetry events from Kafka, scores
them with the current model, and persists high-risk incidents.

Run as its own process/container:
    python -m app.streaming.consumer
"""
import json

from app.config import get_settings
from app.database import SessionLocal
from app.ml.predictor import predict
from app.models import Incident

settings = get_settings()


def run():
    from kafka import KafkaConsumer

    consumer = KafkaConsumer(
        settings.KAFKA_INCIDENT_TOPIC,
        bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="latest",
        group_id="incident-scorer",
    )
    print(f"Listening on '{settings.KAFKA_INCIDENT_TOPIC}'...")

    for msg in consumer:
        payload = msg.value
        result = predict(payload)
        if result["severity"] in ("high", "critical"):
            db = SessionLocal()
            try:
                db.add(Incident(**payload, risk_score=result["risk_score"], severity=result["severity"]))
                db.commit()
            finally:
                db.close()
        print(f"scored {payload.get('service_name')} -> {result}")


if __name__ == "__main__":
    run()
