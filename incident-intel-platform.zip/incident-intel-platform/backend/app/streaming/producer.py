import json
from typing import Optional

from app.config import get_settings

settings = get_settings()
_producer = None


def _get_producer():
    global _producer
    if _producer is not None:
        return _producer
    try:
        from kafka import KafkaProducer

        _producer = KafkaProducer(
            bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        )
    except Exception:
        _producer = None
    return _producer


def publish_incident_event(event: dict) -> bool:
    """Best-effort publish; the API must keep working even if Kafka is down."""
    producer = _get_producer()
    if producer is None:
        return False
    try:
        producer.send(settings.KAFKA_INCIDENT_TOPIC, value=event)
        producer.flush(timeout=2)
        return True
    except Exception:
        return False
