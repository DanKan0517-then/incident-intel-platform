import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.database import Base, engine
from app.routers import health, incidents, predictions

logging.basicConfig(level=logging.INFO)
settings = get_settings()

app = FastAPI(
    title=settings.APP_NAME,
    version="0.1.0",
    description="Predicts production incidents from live service telemetry using an XGBoost model tracked in MLflow.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(predictions.router)
app.include_router(incidents.router)


@app.on_event("startup")
def on_startup():
    # Creates tables if they don't exist yet. For anything beyond local dev,
    # use Alembic migrations instead of relying on this.
    try:
        Base.metadata.create_all(bind=engine)
    except Exception as exc:  # DB may not be up yet in some environments
        logging.warning("Could not initialize database tables: %s", exc)
