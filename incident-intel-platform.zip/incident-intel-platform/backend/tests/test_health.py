import os

os.environ.setdefault("DATABASE_URL", "sqlite:///./test.db")

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_root():
    resp = client.get("/")
    assert resp.status_code == 200
    assert "service" in resp.json()


def test_health():
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert "model_loaded" in body


def test_predict_endpoint():
    payload = {
        "service_name": "checkout-api",
        "error_rate": 0.12,
        "latency_p99_ms": 420,
        "cpu_utilization": 0.7,
        "memory_utilization": 0.65,
        "deploy_frequency_24h": 3,
    }
    resp = client.post("/predict", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert 0 <= body["risk_score"] <= 1
    assert body["severity"] in ("low", "medium", "high", "critical")
